


1. install nix package manaeger in deamon mode https://nixos.org/manual/nix/stable/installation/installing-binary.html?highlight=uninstall#multi-user-installation
2. install nix darvin using https://github.com/LnL7/nix-darwin instructions
